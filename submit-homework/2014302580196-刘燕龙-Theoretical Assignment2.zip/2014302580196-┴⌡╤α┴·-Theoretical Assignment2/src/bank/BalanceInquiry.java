package bank;

public class BalanceInquiry extends Transaction {
	// BalanceInquiry constructor
	
	public BalanceInquiry(int userAccountNumber,
			BankDatabase atmBankDatabase) {
		super(userAccountNumber, atmBankDatabase);
	} // end BalanceInquiry constructor

	// performs the transaction
	@Override
	public void execute() {
		// get references to bank database and screen
		BankDatabase bankDatabase = getBankDatabase();

		// get the available balance for the account involved
		double availableBalance = bankDatabase
				.getAvailableBalance(getAccountNumber());

		// get the total balance for the account involved
		double totalBalance = bankDatabase.getTotalBalance(getAccountNumber());

		// display the balance information on the screen
		GUI.setText("\nBalance Information:");
		GUI.setText(" \n- Available balance: ");
		GUI.setText(String.valueOf(availableBalance));
		GUI.setText("\n - Total balance: ");
		GUI.setText(String.valueOf(totalBalance)+"\n");
	} // end method execute
}
