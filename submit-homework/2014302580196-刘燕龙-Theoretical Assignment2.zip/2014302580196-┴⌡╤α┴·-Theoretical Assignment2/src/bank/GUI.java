package bank;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.BadLocationException;

public class GUI {

	static final long serialVersionUID = 1;
	
	private boolean userAuthenticated; // whether user is authenticated
	private int currentAccountNumber; // current user's account number
	private Keypad keypad; // ATM's keypad
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;

	private JFrame frame;
	private JButton b0;
	private JButton b1;
	private JButton b2;
	private JButton b3;
	private JButton b4;
	private JButton b5;
	private JButton b6;
	private JButton b7;
	private JButton b8;
	private JButton b9;
	private JButton bpoint;
	private JButton bok;
	private JButton bdel;
	protected static JTextArea textArea;
	private JScrollPane sp;

	private Font font;
	private Font font2;

	
	private String bnInput;
	
	public static void setText(String x) {
		textArea.append(x);
	}

	public GUI() {
		 
		bnInput = new String("");
		
		userAuthenticated = false; // user is not authenticated to start
		currentAccountNumber = 0; // no current account number to start
		keypad = new Keypad(); // create keypad
		cashDispenser = new CashDispenser(); // create cash dispenser
		depositSlot = new DepositSlot(); // create deposit slot
		bankDatabase = new BankDatabase(); // create acct info database

		font = new Font("����", Font.BOLD, 25);
		font2 = new Font("����",Font.BOLD,15);
		frame = new JFrame("������ר��ATM");
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setResizable(false);
		frame.setSize(800, 550);
		frame.setLocation(0, 0);

		b0 = new JButton("0");
		b0.setSize(100, 50);
		b0.setLocation(150, 390);
		b0.setFont(font);

		b1 = new JButton("1");
		b1.setSize(100, 50);
		b1.setLocation(150, 210);
		b1.setFont(font);

		b2 = new JButton("2");
		b2.setSize(100, 50);
		b2.setLocation(275, 210);
		b2.setFont(font);

		b3 = new JButton("3");
		b3.setSize(100, 50);
		b3.setLocation(400, 210);
		b3.setFont(font);

		b4 = new JButton("4");
		b4.setSize(100, 50);
		b4.setLocation(150, 270);
		b4.setFont(font);

		b5 = new JButton("5");
		b5.setSize(100, 50);
		b5.setLocation(275, 270);
		b5.setFont(font);

		b6 = new JButton("6");
		b6.setSize(100, 50);
		b6.setLocation(400, 270);
		b6.setFont(font);

		b7 = new JButton("7");
		b7.setSize(100, 50);
		b7.setLocation(150, 330);
		b7.setFont(font);

		b8 = new JButton("8");
		b8.setSize(100, 50);
		b8.setLocation(275, 330);
		b8.setFont(font);

		b9 = new JButton("9");
		b9.setSize(100, 50);
		b9.setLocation(400, 330);
		b9.setFont(font);

		bok = new JButton("ȷ��");
		bok.setSize(120, 230);
		bok.setLocation(525, 210);
		bok.setFont(font);

		bpoint = new JButton(".");
		bpoint.setSize(100, 50);
		bpoint.setLocation(275, 390);
		bpoint.setFont(font);

		bdel = new JButton("ɾ��");
		bdel.setSize(100, 50);
		bdel.setLocation(400, 390);
		bdel.setFont(font);

		textArea = new JTextArea();
		textArea.setFont(font2);
		sp = new JScrollPane(textArea);
		sp.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		sp.setSize(500, 200);
		sp.setLocation(150, 0);
		
		frame.add(b0);
		frame.add(b1);
		frame.add(b2);
		frame.add(b3);
		frame.add(b4);
		frame.add(b5);
		frame.add(b6);
		frame.add(b7);
		frame.add(b8);
		frame.add(b9);
		frame.add(bok);
		frame.add(bpoint);
		frame.add(bdel);
		frame.add(sp);

		myEvent();

		frame.setVisible(true);
	}

	private void myEvent() {
		
		// TODO Auto-generated method stub
		b0.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				textArea.append(b0.getText());
				bnInput = bnInput + "0";
			}
		});

		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b1.getText());
				bnInput = bnInput + "1";
			}
		});

		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b2.getText());
				bnInput = bnInput + "2";
			}
		});

		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b3.getText());
				bnInput = bnInput + "3";
			}
		});

		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b4.getText());
				bnInput = bnInput + "4";
			}
		});

		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b5.getText());
				bnInput = bnInput + "5";
			}
		});

		b6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b6.getText());
				bnInput = bnInput + "6";
			}
		});

		b7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b7.getText());
				bnInput = bnInput + "7";
			}
		});

		b8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b8.getText());
				bnInput = bnInput + "8";
			}
		});

		b9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(b9.getText());
				bnInput = bnInput + "9";
			}
		});

		bpoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append(bpoint.getText());
			}
		});

		bdel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textArea.getText() != null) {
					try {
						textArea.setText(textArea.getText(0, textArea.getText()
								.length() - 1));
						int len = bnInput.length();
						bnInput = bnInput.substring(0,len-1);
					} catch (BadLocationException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		bok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				keypad.setInput(Integer.parseInt(bnInput));
				bnInput = "0";
			}
		});
	}
	
	public void run() {
		// welcome and authenticate user; perform transactions
		while (true) {
			// loop while user is not yet authenticated
			while (!userAuthenticated) {
				textArea.append("\nWelcome");			
				authenticateUser(); // authenticate user
			} // end while

			performTransactions(); // user is now authenticated
			userAuthenticated = false; // reset before next ATM session
			currentAccountNumber = 0; // reset before next ATM session
			textArea.append("\nThank you! Goodbye!");
		} // end while
	} // end method run

	// attempts to authenticate user against database
	private void authenticateUser() {
		textArea.append("\nPlease enter your account number: ");	
		int accountNumber = 0;
		keypad.setInput(0);
		while(accountNumber == 0) {
			accountNumber = keypad.getInput();
		}
		textArea.append("\nEnter your PIN: ");
		int pin = 0;
		keypad.setInput(0);
		while(pin == 0) {
			pin = keypad.getInput();
		}
		// set userAuthenticated to boolean value returned by database
		userAuthenticated = bankDatabase.authenticateUser(accountNumber, pin);
//		System.out.println(userAuthenticated);

		// check whether authentication succeeded
		if (userAuthenticated) {
			currentAccountNumber = accountNumber; // save user's account #
		} // end if
		else
			textArea.append("\nInvalid account number or PIN. Please try again.");
	} // end method authenticateUser

	// display the main menu and perform transactions
	private void performTransactions() {
		// local variable to store transaction currently being processed
		Transaction currentTransaction = null;
		boolean userExited = false; // user has not chosen to exit
		// loop while user has not chosen option to exit system
		while (!userExited) {
			// show main menu and get user selection
			int mainMenuSelection = displayMainMenu();
			// decide how to proceed based on user's menu selection
			switch (mainMenuSelection) {
			// user chose to perform one of three transaction types
			case BALANCE_INQUIRY:
			case WITHDRAWAL:
			case DEPOSIT:
				// initialize as new object of chosen type
				currentTransaction = createTransaction(mainMenuSelection);
				currentTransaction.execute(); // execute transaction
				break;
			case EXIT: // user chose to terminate session
				textArea.append("\nExiting the system...");
				userExited = true; // this ATM session should end
				break;
			default: // user did not enter an integer from 1-4
				textArea.append("\nYou did not enter a valid selection. Try again.");
				break;
			} // end switch
		} // end while
	} // end method performTransactions

	// display the main menu and return an input selection
	public int displayMainMenu() {
		textArea.append("\nMain menu:");
		textArea.append("\n1 - View my balance");
		textArea.append("\n2 - Withdraw cash");
		textArea.append("\n3 - Deposit funds");
		textArea.append("\n4 - Exit");
		textArea.append("\nEnter a choice:");
		int choice=0;
		keypad.setInput(0);
		while(choice == 0) {
			choice = keypad.getInput();
		}
		return choice; // return user's selection
	} // end method displayMainMenu

	// return object of specified Transaction subclass
	private Transaction createTransaction(int type) {
		Transaction temp = null; // temporary Transaction variable
		switch (type) {
		case BALANCE_INQUIRY: // create new BalanceInquiry transaction
			temp = new BalanceInquiry(currentAccountNumber,
					bankDatabase);
			break;
		case WITHDRAWAL: // create new Withdrawal transaction
			temp = new Withdrawal(currentAccountNumber,  bankDatabase,
					keypad, cashDispenser);
			break;
		case DEPOSIT: // create new Deposit transaction
			temp = new Deposit(currentAccountNumber, bankDatabase,
					keypad, depositSlot);
			break;
		} // end switch

		return temp; // return the newly created object
	}
	
}
