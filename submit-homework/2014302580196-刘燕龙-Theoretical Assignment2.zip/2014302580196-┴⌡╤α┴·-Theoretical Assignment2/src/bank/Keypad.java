package bank;

//import java.util.Scanner; // program uses Scanner to obtain user input

public class Keypad {
	private int input;
//	private Scanner input; // reads data from the command line
	// no-argument constructor initializes the Scanner

	public Keypad() {
//		input = new Scanner(System.in);
	} // end no-argument Keypad constructor
	public void setInput( int input) {
		this.input = input;
	}
	// return an integer value entered by user
	public int getInput() {
		//return inputNumber;
		return input; // we assume that user enters an integer
	} // end method getInput
}