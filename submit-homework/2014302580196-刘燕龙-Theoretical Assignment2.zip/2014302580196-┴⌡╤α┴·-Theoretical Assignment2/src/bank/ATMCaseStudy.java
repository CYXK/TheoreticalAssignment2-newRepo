package bank;

public class ATMCaseStudy {
	// main method creates and runs the ATM
	public static void main(String[] args) {
		GUI g = new GUI();
		g.run();
	} // end main
} // end class ATMCaseStudy 